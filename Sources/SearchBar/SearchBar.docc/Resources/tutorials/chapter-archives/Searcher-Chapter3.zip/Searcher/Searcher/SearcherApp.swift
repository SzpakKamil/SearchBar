//
//  SearcherApp.swift
//  Searcher
//
//  Created by KamilSzpak on 04/05/2025.
//

import SwiftUI

@main
struct SearcherApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
