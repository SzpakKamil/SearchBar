//
//  ContentView.swift
//  Searcher
//
//  Created by KamilSzpak on 04/05/2025.
//

import SwiftUI
import SearchBar

struct ContentView: View {
    @State private var searchText = ""
    @State private var currentTokens = [SearchBarToken]()
    let movies: [Movie] = [
        .init(
            title: "Movie 1",
            description: "Loved by many hated by no one.",
            genre: .action
        ),
        .init(
            title: "Everywhere and nowhere",
            description: "Story of a men looking for his son",
            genre: .adventure
        ),
        .init(
            title: "Look! Where?",
            description: "Funny Adventure of two sisters.",
            genre: .adventure
        ),
        .init(
            title: "Where is Dany?",
            description: "Animated movie oriented around...",
            genre: .animation
        ),
        .init(
            title: "CoLOrS",
            description: "Explaining meaning of Color.",
            genre: .animation
        ),
    ]
    var filteredMovies: [Movie] {
        let trimmedSearchText = searchText.trimmingCharacters(in: .whitespaces)
        if trimmedSearchText.isEmpty && currentTokens.isEmpty{
            return movies
        }else if trimmedSearchText.isEmpty{
            return movies.filter{ currentTokens.contains($0.genre.suggestion.token!) }
        }else if currentTokens.isEmpty{
            return movies.filter{ $0.title.localizedStandardContains(trimmedSearchText)}
        }else{
            return movies.filter {
                $0.title.localizedStandardContains(searchText.trimmingCharacters(in: .whitespaces)) && currentTokens.contains($0.genre.suggestion.token!)
            }
        }
    }
    var body: some View {
        let groups = Dictionary(grouping: filteredMovies, by: \.genre)
        let keys = groups.keys.sorted()
        NavigationStack{
            ZStack(alignment: .bottom){
                List{
                    if keys.isEmpty{
                        if currentTokens.isEmpty{
                            Label("No Results found for \"\(searchText.trimmingCharacters(in: .whitespaces))\"", systemImage: "magnifyingglass")
                        }else if searchText.isEmpty{
                            Label("No Results found for token\(currentTokens.count > 1 ? "s" : "") \(currentTokens.map(\.text).joined())", systemImage: "magnifyingglass")
                        }else{
                            Label("No Results found for \"\(searchText.trimmingCharacters(in: .whitespaces))\" and token\(currentTokens.count > 1 ? "s" : "") \(currentTokens.map(\.text).joined(separator: ", "))", systemImage: "magnifyingglass")
                        }
                    }else{
                        ForEach(keys){key in
                            Section(key.name) {
                                ForEach(groups[key] ?? []){
                                    movieRow(for: $0)
                                }
                            }
                        }
                    }
                }
                .safeAreaPadding(.bottom, 80)
                
                SearchBar(text: $searchText)
                    .searchBarIconView{ Image(systemName: "book.pages.fill") }
                    .searchBarClearButtonDisplayMode(.unlessEditing)
                    .searchBarCancelButtonDisplayMode(.always)
                    .searchBarReturnKeyType(.search)
                    .searchBarAutoCorrectionType(.no)
                    .searchBarTextContentType(.emailAddress)
                    .searchBarStyle(.capsule, textColor: .blue, tint: .cyan, tokenBackground: .blue, backgroundColor: .blue.opacity(0.1))
                    .searchBarSuggestions(movies.map(\.suggestion))
                    .searchBarCurrentTokens($currentTokens)
                    .searchBarSuggestedTokens(Genre.allCases.map(\.suggestion))
                    .searchBarEnableAutomaticSuggestionsFiltering{ searchText, suggestion in
                        guard !searchText.isEmpty && searchText.count != suggestion.text.count else {
                            return false
                        }
                        return suggestion.text
                            .localizedStandardContains(searchText)
                    }
                    .padding(.bottom, 20)
                    .background(.bar)
            }
            .navigationTitle("Searcher")
        }
        .animation(.smooth, value: searchText)
    }
    
    func movieRow(for movie: Movie) -> some View {
        Label {
            VStack(alignment: .leading){
                Text(movie.title)
                    .font(.headline)
                Text(movie.description)
            }
        } icon: {
            Image(systemName: movie.genre.systemImage)
        }

    }
}

#Preview {
    ContentView()
}

