//
//  ContentView.swift
//  Searcher
//
//  Created by KamilSzpak on 04/05/2025.
//

import SwiftUI
import SearchBar

struct ContentView: View {
    @State private var searchText = ""
    let movies: [Movie] = [
        .init(
            title: "Movie 1",
            description: "Loved by many hated by no one.",
            genre: .action
        ),
        .init(
            title: "Everywhere and nowhere",
            description: "Story of a men looking for his son",
            genre: .adventure
        ),
        .init(
            title: "Look! Where?",
            description: "Funny Adventure of two sisters.",
            genre: .adventure
        ),
        .init(
            title: "Where is Dany?",
            description: "Animated movie oriented around...",
            genre: .animation
        ),
        .init(
            title: "CoLOrS",
            description: "Explaining meaning of Color.",
            genre: .animation
        ),
    ]
    var filteredMovies: [Movie] {
        guard !searchText.trimmingCharacters(in: .whitespaces).isEmpty else {
            return movies
        }
        return movies.filter {
            $0.title.localizedStandardContains(searchText.trimmingCharacters(in: .whitespaces))
        }
    }
    var body: some View {
        let groups = Dictionary(grouping: filteredMovies, by: \.genre)
        let keys = groups.keys.sorted()
        NavigationStack{
            ZStack(alignment: .bottom){
                List{
                    if keys.isEmpty{
                        Label("No Results found for \"\(searchText.trimmingCharacters(in: .whitespaces))\"", systemImage: "magnifyingglass")
                    }else{
                        ForEach(keys){key in
                            Section(key.name) {
                                ForEach(groups[key] ?? []){
                                    movieRow(for: $0)
                                }
                            }
                        }
                    }
                }
                .safeAreaPadding(.bottom, 80)
                
                SearchBar(text: $searchText)
                    .padding(.bottom, 20)
                    .background(.bar)
            }
            .navigationTitle("Searcher")
        }
        .animation(.smooth, value: searchText)
    }
    
    func movieRow(for movie: Movie) -> some View {
        Label {
            VStack(alignment: .leading){
                Text(movie.title)
                    .font(.headline)
                Text(movie.description)
            }
        } icon: {
            Image(systemName: movie.genre.systemImage)
        }

    }
}

#Preview {
    ContentView()
}

